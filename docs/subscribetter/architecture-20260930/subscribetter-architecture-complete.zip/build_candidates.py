from pathlib import Path
import json

OUT = Path(__file__).resolve().parent
SNAP = json.loads((OUT / 'source-snapshot.json').read_text(encoding='utf-8'))
PREFIX = 'plugins.v3/subscribetter/'


def source(name, start, end, label):
    return dict(path=PREFIX + name, line=start, end_line=end, label=label)


def node(key, kind, label, sublabel, x, y, refs, tag=None):
    value = dict(id=key, type=kind, label=label, sublabel=sublabel,
                 pos=[x, y], size=[240, 80], sources=refs)
    if tag:
        value['tag'] = tag
    return value


def edge(a, b, label, variant='default'):
    return dict(id=a + '-to-' + b, **{'from': a, 'to': b}, label=label, variant=variant)


def card(dot, title, *items):
    return dict(dot=dot, title=title, items=list(items))


def save(slug, title, nodes, edges, cards, views):
    candidate = dict(schema_version=1, diagram_type='architecture',
        meta=dict(title=title, locale='zh-CN', output=f'.archify/{OUT.name}/{slug}.html',
                  quality_profile='showcase', repository=dict(url=SNAP['origin'],
                  revision=SNAP['local_snapshot_revision'], link_mode='local-only'), views=views),
        components=nodes, connections=edges, cards=cards)
    (OUT / (slug + '.json')).write_text(json.dumps(candidate, ensure_ascii=False, indent=2), encoding='utf-8')


N = node
S = source
E = edge
C = card

overview = [
    N('ui','frontend','原生管理界面','Vue / Vuetify · Page / Config',40,70,[S('frontend/src/Config.vue',1,6,'宿主组件'),S('frontend/src/client.mjs',8,26,'宿主 API 与 Save')]),
    N('api','security','管理员 API','Management / Views',400,70,[S('__init__.py',518,524,'管理员与写入门禁'),S('__init__.py',681,711,'API 注册'),S('ui.py',1184,1212,'不可变预览与幂等操作')], '预览 → 核验 → 执行'),
    N('config','security','配置生效与代次','Configuration / Config',760,70,[S('configuration.py',456,485,'配置回执与事务'),S('__init__.py',319,322,'普通工作门禁')],'enabled 且非 dry-run'),
    N('secrets','database','私密存储','SecretStore · POSIX 0600',1120,70,[S('ai.py',406,518,'凭据与原始快照'),S('management.py',334,350,'管理员写入引用')]),
    N('discovery','backend','榜单作品发现','DiscoveryService',40,310,[S('discovery.py',622,637,'唯一来源处理者'),S('discovery.py',1109,1163,'库存、范围与统一提交'),S('site_identity_bridge.py',84,210,'跨来源身份验证')],'唯一 owner / 显式范围'),
    N('migration','security','迁移与切换','Migration · owner 回执',400,310,[S('migration.py',588,662,'切换和回退状态'),S('migration.py',664,682,'当前唯一处理者验证')]),
    N('runtime','backend','统一运行控制','Runtime / Ownership / Scheduler',760,310,[S('runtime.py',235,276,'统一意图提交'),S('ownership.py',26,48,'目标去重与排除'),S('runtime.py',760,794,'有界轮询与恢复')],'同一 tasks / intents / outbox'),
    N('native','external','MoviePilot 原生订阅','NativeAdapter · SubscribeChain',1120,310,[S('mp_adapter.py',67,98,'SDK / Oper 访问'),S('ownership.py',69,112,'创建 S 壳与回读')],'纳管后保持 S'),
    N('rss','external','自建 RSSHub / RSS','有界 HTTP / XML',40,550,[S('discovery.py',208,216,'来源 URL'),S('discovery.py',306,408,'同源与取源限制')]),
    N('guards','security','宿主事件保护','Guard / TransferGuard',400,550,[S('__init__.py',293,313,'监听器与关闭时保护'),S('ownership.py',310,357,'选种、下载、完成否决'),S('execution.py',771,818,'转移保护')],'已纳管范围继续受保护'),
    N('decision','backend','候选决策与计划','Meta → Policy → Authority',760,550,[S('candidates.py',640,716,'物理文件与身份核验'),S('planner.py',872,990,'逐目标安全改善'),S('planner.py',283,357,'观察、冷却与认领')],'身份 / 季集 / 质量 / 代次'),
    N('sites','external','PT 站点与媒体源','SearchChain / MediaChain',1120,550,[S('candidates.py',127,166,'站点 RSS、搜索与媒体识别'),S('runtime.py',45,100,'真实 provider 季集行')]),
    N('files','database','本地下载与监控目录','视频 / 字幕 / 稳定观察',400,790,[S('execution.py',613,698,'整理与内容身份'),S('runtime_assets.py',10,52,'字幕稳定观察'),S('delivery.py',1191,1265,'有界扫描与归属')]),
    N('execution','backend','严格下载与整理','StrictExecutor / Organizer',760,790,[S('execution.py',405,465,'冻结文件表与客户端归属'),S('execution.py',967,983,'TransferChain 与回执'),S('runtime.py',531,587,'下载完成后准备交付')],'授权计划才可派发'),
    N('downloader','external','宿主下载器实例','qBittorrent / Transmission',1120,790,[S('execution.py',31,132,'命名实例与暂停 ADD')],'ADD → 选文件 → RESUME'),
    N('db','database','持久化状态库','subscribetter.sqlite3 · schema 12',40,1030,[S('__init__.py',191,198,'插件数据目录'),S('repository.py',70,190,'完整表与升级'),S('repository.py',193,207,'事务与外键')]),
    N('archive','backend','档案与当前质量','Archive / Mappings / Policy',400,1030,[S('archive.py',545,599,'Emby / STRM / 云内容映射'),S('archive.py',1014,1122,'入库核验与原子激活'),S('archive.py',1235,1364,'扫描与当前事实')]),
    N('delivery','backend','持久交付状态机','Delivery / PublicationGate',760,1030,[S('delivery.py',497,581,'秒传与普通上传'),S('delivery.py',678,746,'发布与消费确认'),S('host_delivery_contract.py',11,26,'适配器组合与发布门禁')],'UNKNOWN 保留原 ID'),
    N('cloud','cloud','115 / CloudDrive2','HostDeliveryCloud',1120,1030,[S('delivery_cloud.py',90,140,'115 秒传与 CD2 通道'),S('delivery_cloud.py',244,292,'目录刷新与移动')],'远端验证后才发布'),
    N('emby','external','选定 Emby 服务 / 库','分页读取与身份确认',400,1270,[S('archive.py',322,388,'宿主 Emby 读取'),S('runtime_delivery.py',19,43,'选定目标的有界查询')]),
    N('consumer','security','消费与入库确认','observe_consumer / confirm_ingest',760,1270,[S('runtime.py',995,1003,'实际观察后确认'),S('runtime_delivery.py',85,107,'内容、STRM 与 Emby 关联'),S('delivery.py',728,746,'未结算继续等待')],'settled 才能 CONFIRMED'),
    N('symedia','external','Symedia / STRM 目录','消费者入口与映射结果',1120,1270,[S('delivery.py',678,716,'发布 incoming 目录'),S('archive.py',80,113,'实际 STRM 读取'),S('archive.py',160,182,'两段路径映射')],'自动补处理能力需外部验证'),
]
overview_edges = [
    E('ui','api','宿主 GET / POST'), E('api','config','配置预检'), E('config','secrets','私密引用'),
    E('api','migration','迁移 / 切换'), E('config','runtime','有效配置','security'),
    E('migration','runtime','owner 核验','security'), E('discovery','runtime','授权后提交','emphasis'),
    E('rss','discovery','榜单输入'), E('runtime','native','创建 / 暂停 / 回读'),
    E('native','guards','宿主事件'), E('runtime','guards','刷新纳管缓存'),
    E('runtime','decision','机会 / 范围','emphasis'), E('decision','sites','搜索 / ID 核验'),
    E('decision','execution','认领后执行','security'), E('execution','downloader','精确客户端操作'),
    E('execution','files','有回执的整理'), E('execution','delivery','完整资产才准备','emphasis'),
    E('delivery','files','Hash / 稳定读取'), E('delivery','cloud','上传 / 验证 / 移动'),
    E('cloud','symedia','授权目录发布','emphasis'), E('delivery','consumer','发布后等待','security'),
    E('consumer','emby','核验实际条目'), E('consumer','symedia','核验 STRM / 内容'),
    E('consumer','archive','完整核验后激活','security'), E('archive','db','Repository 事务'),
    E('archive','decision','当前质量事实','dashed'),
]
save('overview','subscriBetter V3 · 完整架构总览',overview,overview_edges,[
    C('cyan','运行与接口','插件运行在 MoviePilot V3 宿主进程；Vue/Vuetify 模块由宿主 federation 加载。','Management 与 Views 只接受管理员；列表服务器分页，写操作绑定预览、配置版本、代次和精确事实。','配置由父对话框执行宿主 Save；Configuration 回读预检回执后提交，失败保留已生效安全配置。'),
    C('violet','发现与统一纳管','自建 RSSHub 的榜单作品与 PT 下载资源分域；榜单识别不等于下载成功。','手动、发现、原生接管统一走 Runtime.submit / Ownership.submit；STOPPED、RELEASED、排除与目标去重共用。','Migration 对所选旧功能与当前处理者逐步切换；ACTIVE 唯一 owner 回执才放行来源、名称辅助或名称桥。'),
    C('amber','候选、AI 与授权','确定性 Meta 修正优先；AI 仅在名称缺失或可解释歧义时辅助 name/year，仍需媒体源验证 ID。','候选读取真实 torrent 文件表、实际季集行与分类；Policy 准入/排序、Planner 逐目标比较、Authority 原子认领。','观察期、冷却、生命周期、抢占/失败预算、原计划代次和 current_revision 共同约束执行。'),
    C('emerald','字节交付与完成语义','StrictExecutor 使用暂停 ADD、精确文件选择及读回；Organizer 通过宿主 TransferChain 整理。','Delivery 先本地 Hash、115 秒传；有效 MISS 达预算且大小允许时才 CD2 普通上传。','远端内容与目录刷新完成后重新评估发布；消费者经 STRM、云端文件与选定 Emby 实际条目核验后才 CONFIRMED。'),
    C('rose','持久化与恢复','Repository 管理 schema 12 的 tasks/intents/outbox、计划/动作、交付/回执、档案、扫描游标与管理操作。','UNKNOWN 保留原外部 ID 与发布屏障，恢复先沿原 ID 对账；禁止靠超时推断成功或重复派发。','关闭/dry-run 停止普通工作，已纳管事件保护及限定安全对账保留；新代次隔离旧请求，实际 I/O 收尾后关闭资源。'),
    C('slate','源码与验证边界','基于 2026-09-30 当前工作树的 146 个受版本管理插件文件建立本地 Git 快照，包含尚未提交的插件改动。','SRC 引用核验本地快照；没有伪造远端提交链接，没有读取运行凭据或连接真实 NAS/媒体服务。','本图说明源码架构；Symedia 自动补扫、外部服务能力和部署验收不能由图的检查推定。'),
],[dict(id='main',label='订阅执行主链',focus=['runtime','decision','execution','delivery','consumer','archive'],note='统一计划到实际入库确认'),dict(id='control',label='管理与保护',focus=['ui','api','config','migration','guards','native'],note='管理员、唯一 owner 和原生纳管边界'),dict(id='discovery-view',label='作品发现',focus=['rss','discovery','runtime'],note='榜单来源与统一任务共用'),dict(id='delivery-view',label='交付与持久化',focus=['files','delivery','cloud','symedia','consumer','emby','archive','db'],note='字节、发布和入库分别核验')])

decision = [
    N('pt','external','授权 PT 站点','RSS / 站点搜索',40,170,[S('candidates.py',127,149,'站点输入')]),
    N('assist','backend','可选名称辅助','AIService · name / year',400,170,[S('ai.py',963,992,'仅名称歧义回退'),S('ai.py',706,720,'唯一处理者门禁')],'默认关闭 / owner 有效'),
    N('model','external','已配置模型端点','HTTPX · 有界请求',760,170,[S('ai.py',816,924,'TLS、预算与响应限制')]),
    N('candidates','backend','候选采集与证据','CandidateService',40,420,[S('candidates.py',326,434,'有界站点搜索'),S('evidence.py',30,46,'评估证据保存')]),
    N('meta','backend','解析与名称核验','MetaService / MetaCorrector',400,420,[S('meta.py',297,330,'原生解析、确定性修正'),S('candidates.py',454,503,'AI 回退后媒体识别'),S('meta_compat.py',32,86,'可选宿主公共 Meta 包装')]),
    N('identity','security','媒体身份与真实范围','MediaChain / ScopeProvider',760,420,[S('candidates.py',157,166,'低层识别避免事件循环'),S('runtime.py',45,100,'实际季集行与 ID 一致性')],'ID / 类型 / season / episode'),
    N('files','security','真实种子文件表','torrent_table / bind_files',1120,420,[S('candidates.py',512,610,'种子及资产绑定'),S('candidates.py',651,688,'逐物理文件身份与范围')],'文件表完整 / 禁止造集'),
    N('provider','external','真实媒体 Provider','TMDb 等宿主媒体源',760,610,[S('runtime.py',26,43,'公共媒体模块调用'),S('candidates.py',157,166,'实际 ID 验证')]),
    N('current','database','当前档案事实','Archive.current · UNKNOWN 可阻断',400,800,[S('archive.py',626,656,'版本与证据投影'),S('runtime.py',722,726,'未知库存等待')]),
    N('policy','backend','准入与质量偏好','Policy · 分类绑定 / 锁',760,800,[S('policy.py',818,967,'准入解释与质量比较'),S('policy.py',472,490,'有效分类与模板')]),
    N('planner','backend','逐目标安全计划','Planner · 冻结快照',1120,800,[S('planner.py',872,990,'新增、升级、证据及字幕改善'),S('planner.py',157,226,'计划输入与完整文件表')]),
    N('schedule','security','观察 / 冷却 / 生命周期','Scheduler.readiness',760,1060,[S('scheduler.py',76,99,'成熟条件'),S('scheduler.py',106,139,'机会范围去重'),S('scheduler.py',201,258,'生命周期更新')]),
    N('authority','security','原子认领与取代','Authority · owner / revision',1120,1060,[S('planner.py',283,357,'代次、预算、current 及目标锁'),S('planner.py',607,631,'发布最终授权')],'PREPARED → ACTIVE'),
    N('planstore','database','计划、动作与执行证据','Repository · 事务先于派发',760,1320,[S('planner.py',556,583,'在途动作持久化'),S('execution.py',297,336,'操作记账与原 ID 回读')]),
    N('executor','backend','严格执行与重核验','StrictExecutor',1120,1320,[S('candidates.py',730,764,'执行前重评估'),S('execution.py',405,465,'计划、内容和客户端核验')],'实际下载操作另见交付图'),
]
decision_edges = [E('pt','candidates','授权站点输入'),E('candidates','meta','标题 / 副标题'),E('meta','assist','仅名称歧义','dashed'),E('assist','model','owner / 预算允许','security'),E('meta','identity','修正后核验 ID','emphasis'),E('identity','provider','显式媒体查询'),E('identity','files','身份与范围已证','security'),E('files','planner','完整资产范围','emphasis'),E('current','policy','当前版本事实'),E('policy','planner','准入 / 比较 / 锁'),E('planner','authority','冻结计划','emphasis'),E('schedule','authority','成熟且预算允许','security'),E('authority','executor','认领后重核验','security'),E('authority','planstore','持久认领 / 动作'),E('planstore','executor','原操作 ID 对账','dashed')]
save('decision','subscriBetter V3 · 候选决策与授权',decision,decision_edges,[
    C('cyan','输入与解析','PT RSS 和搜索共用 CandidateService；联网有站点、关键词、分页、时间和响应预算。','MetaService 调用宿主 MetaInfo / MetaInfoPath，再由 MetaCorrector 修正并保存原始差异及可重放证据。','可选 MetaPatch 只包装受支持宿主公共入口，默认不自动开启。'),
    C('violet','AI 的权限边界','AI 只建议名称与年份；不能授予下载权、决定文件选择、伪造媒体 ID 或更改季集。','内部辅助要求有效唯一 owner 与代次；可选 NameRecognize 桥同步只查缓存/投队列，由定时任务排空。','HTTPX 请求有并发、队列、重试、响应和预算限制；重启保留未决预算与冷却，不盲目重试。'),
    C('amber','范围与排序','真实 provider 的季集行定义工作范围，episode_count 只可证明覆盖，不用来制造集号。','种子文件名逐个解析并核验物理身份，完整文件表绑定视频、受支持字幕和目标。','Policy 的有效分类、模板覆盖、允许项、分组偏好、谓词和锁决定准入及质量向量；未知证据不强行排序。'),
    C('rose','认领与执行','Planner 比较每个目标的当前事实与候选，保留新增、升级、字幕补充及证据改善的不同动作。','Authority 在事务中核对目标 owner、任务代次、规则/解析修订、档案修订、观察、冷却及取代预算。','执行前再次取得实际资源并验证身份、质量、文件表和归属；过期/未知计划不会旁路执行。'),
],[dict(id='recognition',label='身份与 AI',focus=['candidates','meta','assist','model','identity','provider','files'],note='名称候选仍需真实 ID 和文件范围证明'),dict(id='authorization',label='策略到授权',focus=['current','policy','planner','schedule','authority','planstore','executor'],note='准入、成熟条件、认领和再次核验')])

delivery = [
    N('organizer','backend','宿主整理与回执','Organizer / TransferChain',400,80,[S('execution.py',613,698,'文件身份与整理'),S('execution.py',967,983,'宿主转移结果核验')]),
    N('local','database','本地下载 / 监控文件','真实 inode / 大小 / Hash',760,80,[S('delivery.py',133,181,'描述符绑定及读取'),S('execution.py',624,629,'源内容核验')]),
    N('scan','backend','扫描 / 可选 watcher','LocalReconciler',40,320,[S('delivery.py',1148,1189,'可选提示事件'),S('delivery.py',1191,1265,'重扫与稳定观察')],'扫描不能凭空授予计划'),
    N('bundle','backend','授权资产交付组','Delivery.prepare',400,320,[S('delivery.py',252,326,'完整整理资产与清单'),S('runtime.py',568,586,'准备前重新评估')]),
    N('hash','security','稳定窗口与本地 Hash','LocalSource · 读前复核',400,560,[S('delivery.py',149,181,'本地身份、Hash、范围读'),S('delivery.py',252,326,'稳定与规则验证')]),
    N('upload','backend','上传状态与 outbox','Delivery.reconcile',400,800,[S('delivery.py',497,581,'动作先记账、再发送、后核验')],'UNKNOWN 沿原 ID 对账'),
    N('rapid','backend','115 秒传适配','HostDeliveryCloud.rapid',760,800,[S('delivery_cloud.py',90,112,'实际秒传协议')]),
    N('p115','cloud','115 云盘','目录 / 内容 / 秒传结果',1120,800,[S('delivery_cloud.py',90,112,'HIT / MISS 结果'),S('delivery_cloud.py',36,88,'范围与目录读回')]),
    N('staging','database','隔离暂存目录','云 scope + 明确路径',40,1040,[S('delivery.py',252,326,'隔离目录与 manifest'),S('delivery.py',331,353,'远端验证与主动刷新')]),
    N('remote','security','远端内容独立核验','大小 / Hash / 主动目录刷新',400,1040,[S('delivery.py',331,353,'真实 remote 内容验证'),S('delivery_cloud.py',244,261,'强制刷新父目录')]),
    N('fallback','backend','有界普通上传回退','RemoteUploadChannel / reader',760,1040,[S('delivery.py',528,544,'有效 MISS 与大小预算'),S('delivery_cloud.py',114,140,'先订阅再 Start'),S('delivery_cloud.py',146,242,'原 ID 的有界字节泵')],'MISS 达阈值且大小允许'),
    N('cd2','cloud','CloudDrive2 gRPC','上传 ID / 读回 / 移动',1120,1040,[S('delivery_cloud.py',114,140,'StartRemoteUpload'),S('delivery_cloud.py',285,301,'Move / 精确删除')]),
    N('publish','security','发布前最终重核验','PublicationGate / Authority',400,1280,[S('delivery.py',678,716,'全资产验证与发布'),S('delivery.py',983,1004,'当前质量、范围和排除'),S('planner.py',607,631,'原子发布屏障')],'REMOTE_VERIFIED 才可发布'),
    N('incoming','database','消费者 incoming 目录','完整组移动 / 受限字幕发布',760,1280,[S('delivery.py',678,716,'移动目的目录'),S('delivery.py',661,675,'已验证字幕位置')]),
    N('symedia','external','Symedia 消费者','外部归档与 STRM 生成',1120,1280,[S('delivery.py',728,746,'必须实际 settled 的消费者结果'),S('runtime_delivery.py',15,25,'目标、映射与观察游标')],'补处理能力须实际验证'),
    N('emby','external','选定 Emby 服务 / 库','实际条目与 Provider 身份',40,1520,[S('runtime_delivery.py',19,43,'实际媒体库分页读取')]),
    N('consumer','backend','有界消费者观察','observe_consumer',400,1520,[S('runtime_delivery.py',11,108,'Emby、STRM、云内容的交叉关联'),S('runtime.py',995,1003,'实际观察后才 confirm')],'未结算保持 WAIT_CONSUMER'),
    N('strm','database','MP 可读 STRM 与云目标','两段路径映射 / 真实读回',760,1520,[S('archive.py',80,113,'STRM 流式安全读取'),S('archive.py',160,182,'Emby → STRM → CD2'),S('archive.py',545,599,'原始文件与云身份核验')]),
    N('archive','security','入库确认与档案激活','Archive.confirm_ingest',400,1760,[S('archive.py',1014,1122,'独立重读、质量与原子更新'),S('delivery.py',728,746,'真实 accepted 后 CONFIRMED')],'INGEST_CONFIRMED → PRESENT'),
    N('db','database','持久回执与当前版本','SQLite · 事务 / 修订 / 审计',760,1760,[S('archive.py',1095,1122,'当前版本原子激活'),S('repository.py',193,207,'事务保证')]),
]
delivery_edges=[E('organizer','local','Hash 与整理结果'),E('organizer','bundle','完整整理回执','emphasis'),E('scan','bundle','合法计划与稳定资产','security'),E('bundle','hash','已绑定清单','emphasis'),E('hash','upload','源身份仍一致','security'),E('upload','rapid','优先秒传'),E('rapid','p115','Hash / range / init'),E('upload','remote','远端独立读回','emphasis'),E('upload','fallback','有效 MISS 后回退','dashed'),E('fallback','cd2','原 upload ID / 字节'),E('cd2','p115','普通上传'),E('remote','staging','scope / 内容 / 刷新'),E('remote','publish','全资产 VERIFIED','security'),E('publish','incoming','授权后完整发布','emphasis'),E('incoming','symedia','目录交接'),E('symedia','strm','外部消费结果','dashed'),E('strm','consumer','实际 STRM 与云关联'),E('consumer','emby','实际条目核验'),E('publish','consumer','发布后定期观察'),E('consumer','archive','settled 且完整核验','security'),E('archive','db','原子确认 / 质量更新')]
save('delivery','subscriBetter V3 · 交付、恢复与入库',delivery,delivery_edges,[
    C('cyan','本地字节和资产','Organizer 核验下载完成、文件选择、源大小与完整 Hash，再调用宿主公共 TransferChain 并核对回执。','Delivery.prepare 要求原计划、规则、完整整理回执、稳定窗口与全部资产清单；扫描或 watcher 只是发现提示。','读源拒绝越界、符号链接及身份替换；字幕经历独立稳定观察，未知结果保持等待。'),
    C('amber','秒传与普通上传','秒传 HIT 后独立读回；只有有效 MISS 消耗预算，达到配置阈值且文件大小允许时才 CD2 回退。','CD2 先订阅通道再 Start，持久化 upload ID 后按原请求泵送字节；响应超时保留 UNKNOWN。','主动父目录刷新与云文件大小、Hash 核验完成前，不进入可发布状态。'),
    C('rose','发布屏障与恢复','PublicationGate 重核验身份、准入、范围、排除、当前质量、资产完整及远端内容；Authority 持久化发布屏障。','目录 move 响应未知保持 PUBLISH_OUTCOME_UNKNOWN；目录存在或相同大小不能单独证明成功。','恢复沿原外部 ID 对账，不因时间到期重发或解锁；取消、监控清理、暂存清理、下载器任务和源数据权限独立。'),
    C('emerald','消费者与档案','Symedia 是外部目录消费者，插件不声称自动补处理已发生；缺失消费能力呈现 WAIT_CONSUMER。','observe_consumer 有界读取选定 Emby 条目、实际 STRM、云目录内容与附件，生成精确 settled 回执。','Archive 在激活前再次独立核验身份、Hash、当前质量、代次、排除与修订，事务更新入库回执和 PRESENT 版本。'),
],[dict(id='upload-view',label='上传与回退',focus=['organizer','local','bundle','scan','hash','upload','rapid','p115','fallback','cd2','remote','staging'],note='秒传、普通上传、原 ID 与独立远端核验'),dict(id='ingest-view',label='发布到入库',focus=['remote','publish','incoming','symedia','strm','consumer','emby','archive','db'],note='实际消费者确认是完成条件')])

print(json.dumps({'candidates': ['overview', 'decision', 'delivery'], 'snapshot_revision': SNAP['local_snapshot_revision']}))
