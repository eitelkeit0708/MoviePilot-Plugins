# subscriBetter V3 完整架构图集

交付入口：[subscribetter-full.html](subscribetter-full.html)。单个 HTML 内嵌三张 Archify 完整图，复制该文件即可独立打开、切换视图和分享。每张图保留 Archify 原生主题、搜索、聚焦、路径/上下游探索、来源卡及导出；入口另提供当前原生 HTML 与 JSON 下载。

## 交付内容

| 图 | 节点 | 关系 | 可编辑源 | 原生 HTML | 完整校验回执 |
|---|---:|---:|---|---|---|
| 完整架构总览 | 22 | 26 | overview.json | overview.html | review-2/overview.finalize-summary.json |
| 候选决策与授权 | 15 | 15 | decision.json | decision.html | browser-verified-decision/decision.finalize-summary.json |
| 交付、恢复与入库 | 20 | 21 | delivery.json | delivery.html | browser-verified-delivery/delivery.finalize-summary.json |

57 个节点和 62 条关系是三张视图的合计，同一个系统角色可在多张视图重复出现。

## 源码依据

来源工作树：`D:\projetcs\MoviePilot-Plugins\.worktrees\subscribetter-v3`。

原工作树 HEAD：`7ce7120cdad1a334893908b448f4343954bf6660`。本次没有将尚未提交的改动误记为该提交的内容，也没有修改原工作树、全局技能开关或全局 Git 配置。

2026-09-30 当前 146 个受版本管理插件文件的独立本地 Git 快照：`d4b405fab16e501bff0d798f2a1dd325bb8bb43a`，包含当前未提交插件修改。引用为 `local-only`，Archify 使用 Git 提交内容核验来源。源码快照及 Git 对象保存在 `source-snapshot.zip`；原文件 SHA-256 和改动列表在 `source-snapshot.json`。不包含运行数据库、凭据、NAS 配置或部署文件。

Archify 完整技能/CLI 版本：3.0.1；上游提交：`d5a1333d7447c866a765adac7d4d062f2f02e4d2`。完整运行包和许可证保存在 `archify-runtime.zip`，没有使用 Lite、手工简化模板或代替 Archify 的 Mermaid 输出。

## 覆盖的职责

| 模块 | 在图中的职责 |
|---|---|
| __init__.py / runtime.py | 宿主注册、配置重载、代次隔离、统一任务入口、有界运行和安全恢复 |
| management.py / ui.py / configuration.py | 管理员 API、分页投影、配置预检、不可变操作预览、幂等回执 |
| migration.py | 来源读取、旧配置导入、切换/回退、当前唯一 owner |
| ownership.py / mp_adapter.py | 目标去重、原生 S 壳、SDK/Oper、暂停回读、选种/下载/完成保护 |
| discovery.py / site_identity.py / site_identity_bridge.py | 自建 RSSHub、作品历史、跨来源身份验证、库存和来源范围门禁 |
| meta.py / meta_compat.py / ai.py | 确定性解析、可选公共 Meta 包装、名称辅助、缓存队列和私密存储 |
| candidates.py / policy.py / planner.py / scheduler.py | 真实种子表、物理身份与季集、准入/偏好、逐目标改善、观察/冷却、原子授权 |
| execution.py | 下载器归属、暂停 ADD/选文件/RESUME、共享文件引用、排除、TransferChain 整理 |
| delivery.py / delivery_cloud.py | 资产清单、稳定 Hash、秒传、CD2 原 ID 字节泵、主动刷新、发布、取消和独立清理权限 |
| archive.py / archive_scan.py | Emby/STRM/CD2 映射、库存与质量档案、有界扫描、独立核验、原子版本激活 |
| runtime_passive.py / runtime_assets.py / runtime_delivery.py | 被动来源与扫描、延迟字幕、实际消费者观察和入库关联 |
| repository.py / evidence.py / display.py | schema 12 状态、动作/回执、证据、游标、管理投影 |
| frontend/src 与 dist | 宿主 Page/Config federation 模块、九管理视图和配置 Save |
| host_*_contract.py | 宿主适配组合与显式核验辅助；独立核验函数不作为常态运行服务绘制 |

## 检查结果

- **PASS**：三图 `finalize --quality showcase --repo-root ...` 的 `validate / deliver / check / browser-check` 四门全部通过；严格 artifact check 每图 9 项。
- **PASS**：Archify 检查 1440×900、1600×1000、1920×1080、2048×1320 的桌面容纳、可读性、亮暗主题与 READ/Still 状态，零横向溢出。
- **PASS**：Windows / Chrome 153.0.8010.54 实际打开三张原生图及单文件图集，三视图切换、源码说明对话框、JSON 下载与零脚本错误；390px 检查仅为图集导航容纳。
- **PASS**：人工检查三张 2048px 亮色截图、三张 1440px 全页截图以及总览暗色截图。总览保留一处来源输入与 owner 路线交叉；不同颜色与方向可区分，不表示业务合并。
- **NOT_RUN**：本轮没有连接真实 NAS、下载器、115、CD2、Symedia、Emby 或模型服务；图表检查不代表产品或部署验收。

浏览器和视觉证据分别保存在 `visual-*` 目录与 `package-browser-review.json`。最初沙箱内 Chrome 启动失败记录保留；以表中最终 `finalize-summary` 回执和当前 HTML 哈希为准。视觉判断由独立 `perceptual-review.json` 记录，没有改写 Archify 自动回执的 `not-requested` 或 `pending` 字段。

## 后续修改与重生成

最终 `overview.json / decision.json / delivery.json` 为权威可编辑输入；`build_candidates.py` 仅保留初稿生成过程，不会复现最后的布局修正。

将 `source-snapshot.zip` 与 `archify-runtime.zip` 分别解压至独立本地目录，然后从原工作目录运行，例如：

```powershell
node '<解压后的 Archify>/archify/bin/archify.mjs' finalize architecture `
  .archify/architecture-subscribetter-20260930-191137/overview.json `
  .archify/architecture-subscribetter-20260930-191137/overview.html `
  --repo-root '<解压后的源码快照>' --quality showcase `
  --out-dir .archify/architecture-subscribetter-20260930-191137/next-review --json
```

修改其他图时替换文件名；每次修订使用新的证据目录。需要 Node >=18 和可启动的 Chrome/Chromium。不要去掉完整门禁来把失败标记为通过。三图通过后，`package_artifacts.py` 中的本地工具/快照路径及最终回执目录应按实际位置更新，再重打包单文件入口。
