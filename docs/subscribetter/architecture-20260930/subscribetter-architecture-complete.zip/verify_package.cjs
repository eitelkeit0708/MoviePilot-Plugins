const fs = require('node:fs');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const { chromium } = require('C:/Users/LiuYuZe/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');

(async () => {
  const out = __dirname;
  const browser = await chromium.launch({ executablePath: 'C:/Program Files/Google/Chrome/Application/chrome.exe', headless: true });
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  const evidence = { browser: await browser.version(), platform: process.platform, native: [], portal: [], errors };
  try {
    for (const slug of ['overview', 'decision', 'delivery']) {
      await page.goto(pathToFileURL(path.join(out, slug + '.html')).href);
      await page.waitForSelector('svg');
      await page.evaluate(async () => { await document.fonts.ready; await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r))); });
      const dimensions = await page.evaluate(() => ({ width: innerWidth, scrollWidth: document.documentElement.scrollWidth, scrollHeight: document.documentElement.scrollHeight, svgs: document.querySelectorAll('svg').length }));
      if (dimensions.scrollWidth > dimensions.width) throw new Error(slug + ': horizontal overflow');
      await page.screenshot({ path: path.join(out, slug + '.full-page.png'), fullPage: true });
      evidence.native.push({ slug, status: 'PASS', dimensions, screenshot: slug + '.full-page.png' });
    }
    await page.goto(pathToFileURL(path.join(out, 'subscribetter-full.html')).href);
    for (const label of ['完整总览', '候选决策与授权', '交付、恢复与入库']) {
      await page.getByRole('tab', { name: label }).click();
      const frame = page.frameLocator('#viewer');
      await frame.locator('svg[role="img"][data-reader-fit]').waitFor();
      const count = await frame.locator('[data-node-id]').count();
      const title = await frame.locator('h1').allTextContents();
      const overflow = await frame.locator('html').evaluate(e => e.scrollWidth > innerWidth);
      if (overflow) throw new Error('Portal iframe horizontal overflow: ' + label);
      evidence.portal.push({ label, status: 'PASS', title, semanticNodes: count });
    }
    await page.getByRole('button', { name: '源码与校验' }).click();
    await page.getByRole('dialog').waitFor({ state: 'visible' });
    await page.getByRole('button', { name: '关闭', exact: true }).click();
    await page.getByRole('tab', { name: '完整总览' }).click();
    await page.frameLocator('#viewer').locator('svg[role="img"][data-reader-fit]').waitFor();
    await page.screenshot({ path: path.join(out, 'portal-desktop.png') });
    await page.setViewportSize({ width: 390, height: 844 });
    const mobile = await page.evaluate(() => ({ width: innerWidth, scrollWidth: document.documentElement.scrollWidth, tabs: document.querySelectorAll('[role=tab]').length }));
    if (mobile.scrollWidth > mobile.width || mobile.tabs !== 3) throw new Error('Portal mobile navigation overflow');
    evidence.mobile = { status: 'PASS', ...mobile, limit: 'Navigation containment only; native diagram gate remains the documented desktop viewports.' };
    const download = page.waitForEvent('download');
    await page.getByRole('button', { name: '下载 JSON' }).click();
    const file = await download;
    if (file.suggestedFilename() !== 'overview.json') throw new Error('Wrong JSON download');
    evidence.jsonDownload = 'PASS';
    if (errors.length) throw new Error('Browser JavaScript errors: ' + errors.join('\n'));
    evidence.status = 'PASS';
  } finally {
    fs.writeFileSync(path.join(out, 'package-browser-review.json'), JSON.stringify(evidence, null, 2));
    await browser.close();
  }
  console.log(JSON.stringify(evidence));
})().catch(e => { console.error(e); process.exitCode = 1; });
