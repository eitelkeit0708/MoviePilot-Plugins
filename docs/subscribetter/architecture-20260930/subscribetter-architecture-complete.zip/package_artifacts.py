from pathlib import Path
import base64, hashlib, json, subprocess, zipfile

OUT = Path(__file__).resolve().parent
snapshot = json.loads((OUT / 'source-snapshot.json').read_text(encoding='utf-8'))
archify = Path(r'C:\Users\LiuYuZe\AppData\Local\Temp\codex-archify-20260930-full')
records = []
for slug, label, folder in [('overview','完整总览','review-2'),('decision','候选决策与授权','browser-verified-decision'),('delivery','交付、恢复与入库','browser-verified-delivery')]:
    doc = (OUT / (slug+'.html')).read_bytes()
    spec = json.loads((OUT / (slug+'.json')).read_text(encoding='utf-8'))
    receipt = json.loads((OUT / folder / (slug+'.finalize.json')).read_text())
    assert receipt['ok'] and all(v['status']=='pass' for v in receipt['stages'].values())
    assert receipt['artifact']['sha256'] == hashlib.sha256(doc).hexdigest()
    records.append(dict(id=slug,label=label,html=base64.b64encode(doc).decode(),candidate=spec,
                        sha256=hashlib.sha256(doc).hexdigest(),receipt=folder+'/'+slug+'.finalize-summary.json'))

portal = '''<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>subscriBetter V3 · 完整架构图集</title>
<style>
*{box-sizing:border-box}html,body{margin:0;height:100%;font-family:system-ui,"Microsoft YaHei",sans-serif;color:#17202b;background:#f5f6f8}body{display:flex;flex-direction:column}header{flex:none;display:flex;align-items:center;gap:22px;padding:13px 24px;border-bottom:1px solid #dde2e9;background:#fff}h1{font-size:16px;margin:0;font-weight:750;white-space:nowrap}h1 small{display:block;font-size:11px;color:#66717f;font-weight:500;margin-top:4px}nav{display:flex;gap:5px;flex:1}button{font:inherit;font-size:12px;cursor:pointer;border:1px solid #d9e0e8;background:#fff;color:#536171;border-radius:7px;padding:9px 13px;white-space:nowrap}nav button{border-color:transparent}nav button[aria-selected="true"]{background:#e2f4f6;color:#007e92;font-weight:650}button:focus-visible{outline:2px solid #0697b1;outline-offset:3px}.tools{display:flex;gap:6px}iframe{display:block;width:100%;flex:1;border:0;min-height:0}dialog{max-width:720px;width:calc(100% - 36px);border:1px solid #dce3eb;border-radius:12px;padding:24px;line-height:1.75}dialog::backdrop{background:#10203566}dialog h2{font-size:20px;margin:0 0 14px}dialog p{font-size:13px}dialog code{font-size:11px;overflow-wrap:anywhere}dialog .close{float:right}a{color:#007d95}#status{font-size:11px;color:#62707f}.mobile{display:none}@media(max-width:950px){header{flex-wrap:wrap;gap:10px;padding:10px 14px}h1{flex:1}nav{order:3;flex-basis:100%;overflow:auto}nav button{flex:1}.tools button{padding:7px 9px}}@media(max-width:560px){#savehtml{display:none}h1{font-size:14px}h1 small{font-size:10px}nav button{font-size:11px;padding:9px 7px}}
</style></head><body>
<header><h1>subscriBetter V3<small>完整架构图集 · Archify 3.0.1</small></h1><nav role="tablist" aria-label="架构视图"></nav><div class="tools"><button id="savehtml">保存当前 HTML</button><button id="savejson">下载 JSON</button><button id="about">源码与校验</button></div></header>
<iframe id="viewer" title="完整架构总览" allow="fullscreen"></iframe>
<dialog id="info"><button class="close" id="close">关闭</button><h2>源码与校验依据</h2><p>包含完整架构总览、候选决策与授权、交付恢复与入库三张图。每张图均由 Archify 完整渲染器生成，保留原生搜索、节点聚焦、关系追踪、亮暗主题及导出功能。</p><p id="status"></p><p>依据当前 subscriBetter V3 工作树的 146 个受版本管理插件文件，包括尚未提交的插件修改；独立本地快照已保留。源码引用核验该快照，原工作树未改动。源码架构与真实服务验收分别记录，图的浏览器检查不代表 NAS、下载器、115、Symedia 或 Emby 全链验收。</p><p>源码快照提交：<code>REVISION</code></p><p>JSON 可独立编辑，使用随附完整 Archify 包重新执行 finalize。原始图、证据和源码快照保存在同目录；此入口单个 HTML 已内嵌全部三张图，可独立分享。</p></dialog>
<script type="application/json" id="data">DATA</script>
<script>
const diagrams=JSON.parse(document.getElementById('data').textContent),viewer=document.getElementById('viewer'),nav=document.querySelector('nav');let current=0;
const decode=value=>new TextDecoder().decode(Uint8Array.from(atob(value),c=>c.charCodeAt(0)));
function show(i){current=i;viewer.title=diagrams[i].label;viewer.srcdoc=decode(diagrams[i].html);[...nav.children].forEach((b,n)=>b.setAttribute('aria-selected',String(n===i)));history.replaceState(null,'','#'+diagrams[i].id)}
diagrams.forEach((d,i)=>{const b=document.createElement('button');b.role='tab';b.textContent=d.label;b.onclick=()=>show(i);nav.append(b)});
function download(text,type,name){const url=URL.createObjectURL(new Blob([text],{type})),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}
document.getElementById('savehtml').onclick=()=>download(decode(diagrams[current].html),'text/html;charset=utf-8','subscribetter-'+diagrams[current].id+'.html');
document.getElementById('savejson').onclick=()=>download(JSON.stringify(diagrams[current].candidate,null,2),'application/json;charset=utf-8',diagrams[current].id+'.json');
document.getElementById('about').onclick=()=>document.getElementById('info').showModal();document.getElementById('close').onclick=()=>document.getElementById('info').close();
document.getElementById('status').textContent=diagrams.reduce((n,d)=>n+d.candidate.components.length,0)+' 个视图节点 · '+diagrams.reduce((n,d)=>n+d.candidate.connections.length,0)+' 条关系 · 三图 validate / deliver / check / browser-check 全部 PASS。';
show(Math.max(0,diagrams.findIndex(d=>d.id===location.hash.slice(1))));
</script></body></html>'''
portal = portal.replace('REVISION',snapshot['local_snapshot_revision']).replace('DATA',json.dumps(records,ensure_ascii=False).replace('</','<\\/'))
(OUT/'subscribetter-full.html').write_text(portal,encoding='utf-8')

with zipfile.ZipFile(OUT/'source-snapshot.zip','w',zipfile.ZIP_DEFLATED) as archive:
    root=Path(snapshot['local_snapshot'])
    for path in sorted(root.rglob('*')):
        if path.is_file():archive.write(path,path.relative_to(root))
with zipfile.ZipFile(OUT/'archify-runtime.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for path in sorted((archify/'archify').rglob('*')):
        if path.is_file():archive.write(path,path.relative_to(archify))
    archive.write(archify/'LICENSE','LICENSE')
runtime_revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=archify,text=True).strip()
manifest=dict(archify_version='3.0.1',archify_revision=runtime_revision,snapshot_revision=snapshot['local_snapshot_revision'],
              diagrams=[{k:v for k,v in d.items() if k not in ('html','candidate')} for d in records],
              native_archify_full_renderer=True,quality='showcase',browser_evidence='PASS',
              visual_review='Three 2048x1320 light screenshots inspected; full page and dark review follow separately')
(OUT/'delivery-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(portal=str(OUT/'subscribetter-full.html'),nodes=sum(len(d['candidate']['components']) for d in records),relationships=sum(len(d['candidate']['connections']) for d in records),archify_revision=runtime_revision),indent=2))
